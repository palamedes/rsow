<?php
/*
Plugin Name: WP Desired Functionality
Plugin URI: 
Description: This is a collection of "desired functionality" that wordpress, for whatever reason, was either lacking completely or in my opinion did incorrectly.. I will also be adding new functionality to this plugin from time to time, so keep it up to date.
Version: v0.4 for 2.05+
Author: Jason Ellis
Author URI: http://www.randomstringofwords.com
*/

/** Desired Functionality 01
 *
 * Functions
 * - pal_list_categories($args = '') :: similar to wp_list_cats 
 *  
 * Written By Jason Ellis [Palamedes@rocketmail.com]
 * "My coding style is my own.. good,bad - ugly.. I'm the one at the keyboard." - Jason
 * "Much of the documentation I write in my code, is as much for me as it is for you." - Jason  
 */

define('pal_desiredFunctions01', true);



/** List Categories
 * This function is meant to replace wp_list_cats and list_cats entirely. Need a feature? Ask.
 * 
 * Valid Args:
 *  start = 0 ~ The starting "most parent" category, 0 means start at top, 0 is default.
 * 	exclude = 50,4,23 ~ A list of categories you want to exclude in a comma delimited list
 * 	orderby = id || name ~ you may order by either ID or NAME, ID is default
 * 	orderdir = asc || desc ~ you may order either ascending or descending, asc is default
 * 	depth = 1 ~ How many levels down do you want to display?, 1 is default (so start=0&depth=1 shows top parents and first children) 0 means none
 * 	show_count = 1 or 0 ~ Displays the number of posts in the category link, 0 by default (false/off)
 * 	show_count_zero =  1 or 0 ~ If a category has ZERO posts, display (0) or not, 0 by default which hides (0)
 *	use_desc_for_title = 1 or 0 ~ Shows the description as the title of the link (for mouse hover), 0 by default which is off
 * 	hide_empty = 1 or 0 ~ Hide categories that are empty NOTE: Hides parents that have children with content too.. so.. use with caution	 
 *	parent_style = {stylename} ~ Defines the style of the IMMEDIATE PARENT of the CURRENTLY SELECTED category, defaults to "parent-cat" 
 * 	current_style = {stylename} ~ Defines the style of the "current" open category, defaults to "current-cat"
 *	children_style = {stylename} ~ Defines the UL style of a block of children, defaults to "children"
 *	show_count_style = {stylename} ~ Defines the style of the count span, defaults to "cat-count"     
 */ 
function pal_list_categories($args = '') {
	// Yank in the args	
	parse_str($args, $param);
	// Grab the cats as we know them based on the input
	$cats = pal_parse_categories($args);
	// Now grab all cats for close child/parent relation
	$relations = pal_get_categories("-1");
	if (is_array($relations)) {
		foreach($relations as $val) {
			$rels[$val['category_parent']][] = $val['cat_ID'];
		}
	}
	// Create the output
	$results = pal_display_cats($args, $cats, $rels);
	// Output
	print $results;
}



/** get_categories -- PRIVATE FUNCTION ~ don't call this directly
 * This function gets all categories minus those in the exlude list or those that are empty when 
 * its set from the database and returns them as an array for the next function to do something with.
 */
function pal_get_categories($parentCategory = '0', $excluding = '', $orderby = 'id', $orderdir = 'asc', $hide_empty = false) {
	global $wpdb;
	// Scrub ParentCategory
	$parentCategory = intval(preg_replace('/[^\d-]/','',$parentCategory));
	// Scrub Excluding
	$excluding = preg_replace('/[^\d,]/','',$excluding);
	// Scrub Orderby
	$orderby = strtolower($orderby);
	$orderby = ($orderby == 'id')?'cat_ID':'cat_name';
	// Scrub Orderdir
	$orderdir = strtolower($orderdir);
	$orderdir = ($orderdir == 'asc' || $orderdir == 'desc')?$orderdir:'asc';
	// Build the SQL
	$SQL  = 'select * from '.$wpdb->categories.' where ';
	$SQL .= (($parentCategory == "-1")?'cat_ID > 0 ':'category_parent = '.$parentCategory.' ');
	$SQL .= (empty($excluding))?'':' and cat_ID not in ('.$excluding.') ';
	$SQL .= ($hide_empty)?' and category_count != 0 ':'';
	$SQL .= 'order by '.$orderby.' '.$orderdir;	
	// Return it as an array
	return $wpdb->get_results($SQL, 'ARRAY_A');
}

/** This function returns a given categories db information based on the name of the category.
 * This function is here because WP's get_the_categories function is terribly broken as of 2.05
 * Note: I intentionally ONLY return one.
 */
function pal_getCategoryByName($catname) {
	global $wpdb;
	$SQL  = 'select * from '.$wpdb->categories.' where ';
	$SQL .= 'cat_name = "'.$catname.'";';
	$res = $wpdb->get_results($SQL);
	return $res[0];
}

/** Parse categories -- PRIVATE FUNCTION ~ don't call this directly
 * This function does the work of looping through an array of categories and sorting out what
 * to do with the information - to include the children - this really is the work horse
 */  
function pal_parse_categories($args = '', $level = 0) {
	// This is the level we are at
	$level++;
	// Yank in the args	
	parse_str($args, $param);
	// Get our category array
	$categoryArray = pal_get_categories($param['start'], $param['exclude'], $param['orderby'], $param['orderdir'], $param['hide_empty']);
	// Create our results array
	$resultsArray = array();
	// Go get the children if we have a requested depth but only go down "Depth" number of levels
	if ($param['depth']>'0' && is_array($categoryArray)) {
		foreach($categoryArray as $catKey=>$catVal) {
			if ($level <= $param['depth']) {
				$categoryArray[$catKey]['children'] = pal_parse_categories(
					"start=".$catVal['cat_ID'].
					"&exclude=".$param['exclude'].
					"&orderby=".$catVal['orderby'].
					"&orderdir=".$catVal['orderdir'].
					"&depth=".$param['depth']
					, $level);
			}		
		}
	}
	return $categoryArray;
}

/** display_cats -- PRIVATE FUNCTION ~ don't call this directly
 * This function builds the HTML output for the categories and it's children
 * 
 * If there is something you would like changed please ask me for it instead
 * of just changing it - that way I can make it available to everyone. Thanks   
 */ 
function pal_display_cats($args, $cats, $rels, $child = false) {
	global $wp_query;
	$results = '';
	if (is_array($cats)) { 
		parse_str($args, $param);
	
		// is this a child?  Add a UL
		if ($child) { 
			$results .= '<ul class="'.(($param['children_style'])?$param['children_style']:'children').'">'."\n";	
		}
		// Step through the cat loop and output the LI's	
		foreach ($cats as $val) {
			// Create the list item and create the correct class for it (make damn sure it's a category and not a page
			$results .= '<li class="'.(($val['cat_ID'] == $wp_query->get_queried_object_id() && is_category())?
						// add the currently selected style
						(($param['current_style'])?$param['current_style']:'current-cat'):'').' '.
						// add the parents style (sorry for this one)
						((is_array($rels[$val['cat_ID']]) && in_array( $wp_query->get_queried_object_id() , $rels[$val['cat_ID']] ) && is_category())?
							($param['parent_style'])?$param['parent_style']:'parent-cat':'').' '.
						// Close styles and add link
						'"><a href="'.get_category_link($val['cat_ID']).'" ';
			// We using the description for the title?
			if ($param['use_desc_for_title'] == false || empty ($val['category_description'])) {
				$results .= 'title="View all posts filed under '.wp_specialchars($val['cat_name']).'"';
			} else {
				$results .= 'title="'.wp_specialchars($val['category_description']).'"';
			}
			// Close the link and display the category name
			$results .= '>' . wp_specialchars($val['cat_name']);
			// If they want us to show the count then put it here 		
			if ($param['show_count']) {
				if (($param['show_count_zero'] && $val['category_count'] == 0) || $val['category_count'] != 0) {
					$results .= ' <span class="'.(($param['show_count_style'])?$param['show_count_style']:'cat-count').'">('					 
						. wp_specialchars($val['category_count']) .')</span>';
				}
			}
			// Close the anchor and the li
			$results .= '</a></li>'."\n";
			
			// Does this cat have a child?  Display them
			if (isset($val['children']) && !empty($val['children'])) {
				$results .= pal_display_cats($args, $val['children'], $rels, true);
			}
		}
		// is this a child? Close that UL
		if ($child) {
			$results .= '</ul>'."\n";
		}
	}
	return $results;
}



?>
